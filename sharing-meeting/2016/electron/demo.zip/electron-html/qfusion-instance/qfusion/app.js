let appIcon = null;
// 载入electron模块
var electron=require('electron');
// 创建应用程序对象
var app=electron.app;
// 创建一个浏览器窗口，主要用来加载HTML页面
var BrowserWindow=electron.BrowserWindow;
// 声明一个BrowserWindow对象实例
var mainWindow;
// const dialog = electron.dialog;
const Menu = electron.Menu;
const MenuItem = electron.MenuItem;
const Tray = electron.Tray;
//picture
const nativeImage = electron.nativeImage;
const path = __dirname;
var image = nativeImage.createFromPath(path.replace(/\\/g, '/')+'/favicon.png');
// var image = 'file://'+__dirname+'/favicon.png';

//判断是否第一个实例
const shouldQuit = app.makeSingleInstance((argv, workingDirectory) => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) {
      mainWindow.restore();
    } else if(!mainWindow.isVisible()) {
      mainWindow.show();
    }
    mainWindow.focus();
  }
});

//是否退出当前实例
if (shouldQuit) {
  app.quit();
}

if(process.platform === 'win32') {
  image = nativeImage.createFromPath(path.replace(/\\/g, '/')+'/favicon.ico');
  // image = 'file://'+__dirname+'/favicon.ico';
}

// var menu = new Menu();
// menu.append(new MenuItem({ label: 'MenuItem1', click: function() { console.log('item 1 clicked'); } }));
// menu.append(new MenuItem({ type: 'separator' }));
// menu.append(new MenuItem({ label: 'MenuItem2', type: 'checkbox', checked: true }));

var template = [
  {
    label: '关于',
    click: function() { electron.shell.openExternal('http://www.woqutech.com/')},
  },
  {
    label: '退出',
    click: function() { mainWindow.destroy();app.quit(); }
  },
];

var menu = Menu.buildFromTemplate(template);

//定义一个创建浏览器窗口的方法
function createWindow(){
    //设置菜单
    Menu.setApplicationMenu(menu);
    // 创建一个浏览器窗口对象，并指定窗口的大小
    mainWindow=new BrowserWindow({
        width: 1366,
        minWidth: 1000,
        height: 800,
        title: 'QFusion',
        darkTheme: true, //为窗口使用 dark 主题, 只在一些拥有 GTK+3 桌面环境上有效. 默认为 false.
        experimentalFeatures: true,//开启 Chromium 的 可测试 特性. 默认为 false
        enableLargerThanScreen: true, //是否允许允许改变窗口大小大于屏幕. 默认是 false
        skipTaskbar: false, //是否在任务栏中显示窗口
        icon: image,
    });
    
    // mainWindow.setRepresentedFilename('/etc/passwd');
    // mainWindow.setDocumentEdited(true);

    // 通过浏览器窗口对象加载index.html文件，同时也是可以加载一个互联网地址的
    mainWindow.loadURL('file://'+__dirname+'/qfusion_app/index.html'); 
    // 同时也可以简化成：mainWindow.loadURL('./index.html');

    // 监听浏览器窗口对象是否关闭，关闭之后直接将mainWindow指向空引用，也就是回收对象内存空间
    mainWindow.on('close',function(e){
      e.preventDefault();
      mainWindow.hide();
    });
}

//第一次打开
function initWindow() {
  createWindow();
  appIcon = new Tray(image);
  appIcon.setImage(image);
  var contextMenu = Menu.buildFromTemplate([
    { label: '关于', type: 'normal', click: function() { electron.shell.openExternal('http://www.woqutech.com/')}, },
    { label: '退出', type: 'normal', click: function() { mainWindow.destroy(); app.quit(); }, },
  ]);
  appIcon.setToolTip('QFusion');
  appIcon.setContextMenu(contextMenu);
  appIcon.on('click', function() {
    mainWindow.show();
  });
}

// 监听应用程序对象是否初始化完成，初始化完成之后即可创建浏览器窗口
app.on('ready', initWindow);

// 监听应用程序对象中的所有浏览器窗口对象是否全部被关闭，如果全部被关闭，则退出整个应用程序。该
app.on('window-all-closed',function(){
    // 判断当前操作系统是否是window系统，因为这个事件只作用在window系统中
    if(process.platform!='darwin'){
        // 退出整个应用程序
        // app.quit();
    }
});

// 监听应用程序图标被通过点或者没有任何浏览器窗口显示在桌面上，那我们应该重新创建并打开浏览器窗口，避免Mac OS X系统回收或者销毁浏览器窗口
app.on('activate',function(){
    if(mainWindow===null){
        createWindow();
    }
});