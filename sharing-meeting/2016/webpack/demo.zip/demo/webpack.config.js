var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var ExtractTextPlugin = require("extract-text-webpack-plugin");

module.exports = {
  entry: [
    'webpack-dev-server/client?http://localhost:8080',
    'webpack/hot/dev-server',
    './index.js'
  ],
  output: {
    path: __dirname+'/dist',
    filename: 'index.js',
    chunkFilename: '[name].js',
    //publicPath: 'http://localhost:8080/dist'
  },
  resolve:{
    extensions:['','.js','.css']
  },
  module: {
    loaders: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        loader: 'babel',
        query: {
          presets: ['es2015']
        }
      },
      //{test: /\.css$/, loader: 'style!css'},
      {test: /\.css$/, loader: ExtractTextPlugin.extract("style-loader", "css-loader") },
      {test: /\.png$/, loader: 'url-loader?limit=10000000&name=[path][name].[ext]' },
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './index.html',
      filename: 'index.html',
      inject: 'body',
      minify:{
        removeComments:true,
        collapseWhitespace:true
      }
    }),
    new ExtractTextPlugin("style.css"),
    new webpack.HotModuleReplacementPlugin(),
  ],
};
