const B = 'B.js';
setTimeout(()=> {
  require.ensure(['./C'],function(require){
    var aModule = require('./C');
  },'C');
}, 10000);
module.exports = B;