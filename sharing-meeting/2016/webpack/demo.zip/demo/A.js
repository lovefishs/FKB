var A = 'A.js';

module.exports = A;