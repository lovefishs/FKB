function c() {
  console.log('C.js可运行');
}