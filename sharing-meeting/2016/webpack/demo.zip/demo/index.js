var A = require('./A');
import B from './B';

var img = require('./img/img.png');
require('./style.css');
console.log(img, 11111 );

var imgPanel = document.getElementById('img');
var imgTag = document.createElement('img');
imgTag.src = img;
imgPanel.appendChild(imgTag);
