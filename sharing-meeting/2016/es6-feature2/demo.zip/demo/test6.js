/*参数默认值*/

//传统写法
var link = function (height, color, url) {
  var height = height || 50;
  var color = color || 'red';
  var url = url || 'http://azat.co';
  return height;
}

//ES6
var link = function(height = 50, color = 'red', url = 'http://azat.co') {
  return height;
}

console.log(link());


