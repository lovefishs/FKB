/*箭头函数*/

var array = [1, 2, 3];

//传统写法
array.forEach(function(v) {
  console.log(v);
});

var logUpperCase = function() {
  var _this = this;
  this.string = this.string.toUpperCase();
  return function () {
    return console.log(_this.string);
  }
}
logUpperCase.call({ string: 'es6 rocks' })();

//ES6
array.forEach(v => {
  console.log(v);
});

var logUpperCase = function() {
  this.string = this.string.toUpperCase();
  return () => console.log(this.string);
}
logUpperCase.call({ string: 'es6 rocks' })();
