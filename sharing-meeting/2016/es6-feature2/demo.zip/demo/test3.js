/*增强的字面量*/

var serviceBase = {port: 3000, url: 'azat.co'},
getAccounts = function(){return [1,2,3]};

//传统写法
var accountServiceES5 = {
  port: serviceBase.port,
  url: serviceBase.url,
  getAccounts: getAccounts,
  getUrl: function() {return "http://" + this.url + ':' + this.port},
  valueOf_1_2_3: getAccounts()
}

//ES6
var accountService = {
    __proto__: serviceBase,
    getAccounts,
    getUrl() {return "http://" + this.url + ':' + this.port},
    [ 'valueOf_' + getAccounts().join('_') ]: getAccounts()
};
console.log(accountServiceES5, accountService);
