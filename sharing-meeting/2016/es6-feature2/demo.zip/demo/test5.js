/*参数模板*/

var id = 1;
var a = '这是nt'
    +'换行';
var b = `这是
换行`;
//传统写法
console.log('我的id是：'+id, a);
//ES6
console.log(`我的id是：${id}`, b);
