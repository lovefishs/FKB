/*解构*/

function data() {
  return {
    house: 'xx',
    mouse: 'yy',
  };
}

// 传统写法
var data = data(), // data has properties house and mouse
    house = data.house,
    mouse = data.mouse;

//ES6
// var {house, mouse} = data();

console.log(house, mouse);
